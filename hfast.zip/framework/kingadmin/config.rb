http_path = "/"
css_dir = "/css"
images_dir = "/img"
fonts_dir = "/fonts"
relative_assets = true

# dev
#line_comments = true;

# delivery
line_comments = false;

# prod/demo
#line_comments = false;
#output_style = :compressed;

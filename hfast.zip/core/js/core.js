/**
 * @author:
 * @date: 15-1-8
 */
define(["core/js/grid/grid"], function (URI,grid) {
	kendo.culture($global.BaseFramework.locale);
    grid.run();
});
